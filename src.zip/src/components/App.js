import React from "react";
import "./App.css";

import DataContainer from "./DataContainer";

const App = () => [<div><h1><center>UiNames</center></h1></div>, <DataContainer />];

export default App;
